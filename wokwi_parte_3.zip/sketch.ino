// João Henrique Viana de Oliveira - 15462907
// Pedro Brandi Pereira - 15640990

// Controle de servomotor com display OLED

#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <ESP32Servo.h>

// Configuração do Display OLED 128x64 via I2C
const int display_largura = 128;
const int display_altura = 64;
Adafruit_SSD1306 display(display_largura, display_altura, &Wire, -1);

// Pinos de entrada e saída
const int pino_pot = 34;
const int pino_botao = 4;
const int pino_servo = 18;

Servo servo;

// Variáveis voláteis para uso na interrupção
volatile bool sentido_horario = true;
volatile unsigned long ultimo_acionamento = 0;

// Rotina de interrupção (ISR) para o botão
void IRAM_ATTR inverter_sentido() {
  // Debounce por software de 250 ms
  if (millis() - ultimo_acionamento > 250) {
    sentido_horario = !sentido_horario;
    ultimo_acionamento = millis();
  }
}

void setup() {
  Serial.begin(115200);

  // Configuração da interrupção no botão
  pinMode(pino_botao, INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(pino_botao), inverter_sentido, FALLING);

  // Inicialização do display
  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println("Display OLED nao reconhecido.");
    for (;;); // Trava o sistema em caso de erro de hardware
  }
  display.clearDisplay();

  // Configura o controle do servo
  servo.attach(pino_servo, 500, 2400);
}

void loop() {
  // Leitura da velocidade desejada
  int leitura_adc = analogRead(pino_pot);

  // Conversão da escala do ADC (0-4095) para ângulo do servo (0-180) em float
  float angulo = (leitura_adc / 4095.0f) * 180.0f;

  servo.write(sentido_horario ? angulo : 180.0f - angulo);

  // Monitoramento via UART
  Serial.print("Sentido: ");
  Serial.println(sentido_horario ? "Horario" : "Anti-Horario");
  Serial.print("Angulo: ");
  Serial.print(angulo, 1);
  Serial.println("°");

  // Monitoramento via display OLED
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  
  display.setCursor(0, 0);
  display.println("Controle de Servo");
  display.drawLine(0, 10, 128, 10, SSD1306_WHITE);
  
  display.setCursor(0, 22);
  display.print("Sentido: ");
  display.println(sentido_horario ? "Horario" : "Anti-Hor.");
  
  display.setCursor(0, 40);
  display.print("Angulo: ");
  display.print(angulo);
  display.println("o");

  display.display();
  
  // Taxa de atualização da tela e serial
  delay(100);
}
