// João Henrique Viana de Oliveira - 15462907
// Pedro Brandi Pereira - 15640990

// Controle de LED RGB por PWM

// Definição dos pinos usados pelo LED
const int pino_r = 21;
const int pino_g = 19;
const int pino_b = 18;

// Configurações do PWM
const int frequencia = 5000; // Frequência de 5 kHz
const int resolucao = 8; // Resolução de 8 bits (0 a 255)

// Variáveis para armazenamento do duty cycle e passos de incremento
int duty_r = 240;
int passo_r = 15;

int duty_g = 240;
int passo_g = 5;

int duty_b = 240;
int passo_b = 10;

void setup() {
  // Inicialização da comunicação serial UART a 115200 baud rate
  Serial.begin(115200);

  // Configuração dos canais PWM com frequência e resolução de cada LED
  ledcAttach(pino_r, frequencia, resolucao);
  ledcAttach(pino_g, frequencia, resolucao);
  ledcAttach(pino_b, frequencia, resolucao);
}

void loop() {
  // Atualização do duty cycle de cada LED
  ledcWrite(pino_r, duty_r);
  ledcWrite(pino_g, duty_g);
  ledcWrite(pino_b, duty_b);

  // Envio de informações pelo UART
  Serial.print("Vermelho: ");
  Serial.print(duty_r); 
  Serial.print(" (+");
  Serial.print(passo_r);
  Serial.print(") | ");

  Serial.print("Verde: ");
  Serial.print(duty_g); 
  Serial.print(" (+");
  Serial.print(passo_g);
  Serial.print(") | ");

  Serial.print("Azul: ");
  Serial.print(duty_b); 
  Serial.print(" (+");
  Serial.print(passo_b);
  Serial.println(")");

  // Atualização dos duty cycles para o próximo ciclo
  duty_r += passo_r;
  if (duty_r > 255) duty_r = 0;

  duty_g += passo_g;
  if (duty_g > 255) duty_g = 0;

  duty_b += passo_b;
  if (duty_b > 255) duty_b = 0;

  // Atraso de 500 ms para permitir a visualização gradativa
  delay(500);
}
