// João Henrique Viana de Oliveira - 15462907
// Pedro Brandi Pereira - 15640990

// Controle de servomotor PWM

#include <ESP32Servo.h>

Servo servo;

// Definição dos pinos usados pelo servo e potenciômetro
const int pino_pot = 34;
const int pino_servo = 13;

void setup() {
  // Inicialização da comunicação serial UART a 115200 baud rate
  Serial.begin(115200);
  
  // Define o pino do servo e os valores de tempo mínimo e máximo em microssegundos
  servo.attach(pino_servo, 500, 2400); 
}

void loop() {
  // Leitura de 12 bits do ADC
  int leitura_adc = analogRead(pino_pot);
  
  // Conversão da escala do ADC (0-4095) para o ângulo do servo (0-180)
  int angulo = map(leitura_adc, 0, 4095, 0, 180);
  
  // Posiciona o servo no ângulo desejado
  servo.write(angulo);

  // Monitoramento
  Serial.print("Leitura do ADC: ");
  Serial.println(leitura_adc);
  
  Serial.print("Angulo: ");
  Serial.println(angulo);
  Serial.println();

  delay(50);
}